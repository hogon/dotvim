LanguageTool is published under the GNU Lesser General Public License (LGPL).
For more detailed license information, see COPYING.txt and README.txt.

This is the list of libraries used by LanguageTool and their licenses:

bliki.jar: Eclipse Public License 1.0, http://code.google.com/p/gwtwiki/
CJFtransform_v1.0.1_bin.jar: Apache License 2.0, http://code.google.com/p/cjftransform/
commons-lang.jar: Apache License 2.0, http://commons.apache.org/lang/
commons-logging.jar: Apache License 2.0, http://commons.apache.org/logging/
commons-validator.jar: Apache License 2.0, http://commons.apache.org/validator/
ictclas4j-1.0.jar: ictclas4j-license.txt, Apache License 2.0, http://code.google.com/p/ictclas4j/
junit.jar: Common Public License - v 1.0, CPL.txt, http://www.junit.org
jWordSplitter.jar: Apache License 2.0, http://www.danielnaber.de/jwordsplitter/
lucene-*.jar: Apache License 2.0, http://lucene.apache.org
morfologik-*.jar: Morfologik-license.txt, http://morfologik.blogspot.com, http://www.cs.put.poznan.pl/dweiss
segment-1.3.0.jar: segment-license.txt, http://sourceforge.net/projects/segment/
tika-core-0.9.jar: Apache License 2.0, http://tika.apache.org
xml-text-editor-0.0.3.jar: Apache License 2.0, http://code.google.com/p/xml-text-editor/
